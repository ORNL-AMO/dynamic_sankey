var mytitle;
var numNode =1;
var numLink =1;
var Label = ["outlet","fan","computer","waste"];
var Source = [];
var dest = [];
var linkVal= [];

 function setTitle()
{
	mytitle = document.getElementById("title").value;
}

function setLabel(numN)
{
	Label[numN]=document.getElementById("label"+String(numN)).value;
}

function setSource(numL)
{
	Source[numL]=document.getElementById("source"+String(numL)).value;
}

function setDest(numL)
{
	dest[numL]=document.getElementById("dest"+String(numL)).value;
}

function setLinkVal(numL)
{
	linkVal[numL]=document.getElementById("linkVal"+String(numL)).value;
}

function addInput()
{
    var makeInputs = document.getElementById("makeInputs");

    var newInput = document.createElement("td");
    newInput.innerHTML = "<div class='col-sm-2'>"+
			"<div style='width: 225px;  display: inline-block;'>"+
				"<table class='table table-bordered' style='margin: 0px;'>"+
					"<tbody>"+
						"<tr id='inputs'>"+
							"<td style='width:120px' class='text-center'>"+
								"<h3 style='margin-top: 5px'>Node "+numNode+"</h3>"+
								"<div class='input-group'>"+
									"<span class='input-group-addon'>name</span>"+
									"<input type='text' class='form-control' aria-describedby='basic-addon1' onchange='setLabel("+numNode+")' style='width: 145px' id='label"+String(numNode)+"'>"+
								"</div>"+
								"<div class='input-group'>"+
									"<span class='input-group-addon' id='basic-addon1'>value</span>"+
									"<input type='text' class='form-control' aria-describedby='basic-addon1' onchange='updateDifference()' style='width: 145px'>"+
								"</div>"+
								"<div class='input-group'>"+
									"<span class='input-group-addon' id='basic-addon1'>units</span>"+
									"<input type='text' class='form-control' aria-describedby='basic-addon1' onchange='updateDifference()' style='width: 150px'>"+
								"</div>"+
								"<div class='form-group' style='width: 205px'>"+
								//DELETE THE THING
								"<button class='btn btn-secondary' onclick='deleteInput()' style='background-color: #8f3236'><span class='glyphicon glyphicon-minus'></span></button>"+
									"<select class='form-control' id='sel1'>"+
									
							
									  "<option>Red</option>"+
									  "<option>Blue</option>"+
									  "<option>Yellow</option>"+
									  "<option>Orange</option>"+
									  "<option>Green</option>"+
									  "<option>Blue</option>"+
									  "<option>Purple</option>"+
									  "<option>Brown</option>"+
									"</select>"+
								  "</div>"+	
							"</td>"+
						"</tr>"+
					"</tbody>"+
				"</table>"+
			"</div>"+
		"</div>";
	
	
    makeInputs.appendChild(newInput);
    numNode++;
}

function addLink()
{
    var makeLinks = document.getElementById("makeLinks");

    var newLink = document.createElement("td");
    newLink.innerHTML = "<div class='col-sm-2'>"+
			"<div style='width: 275px;  display: inline-block;'>"+
				"<table class='table table-bordered' style='margin: 0px;'>"+
					"<tbody>"+
						"<tr id='inputs'>"+
							"<td style='width:120px' class='text-center'>"+
								"<h3 style='margin-top: 5px'>Link "+numLink+"</h3>"+
								"<div class='input-group'>"+
									"<span class='input-group-addon'>source#</span>"+
									"<input type='text' class='form-control' aria-describedby='basic-addon1' onchange='setSource("+numLink+")' style='width: 175px' id='source"+String(numLink)+"'>"+
								"</div>"+
								"<div class='input-group'>"+
									"<span class='input-group-addon'>destination#</span>"+
									"<input type='text' class='form-control' aria-describedby='basic-addon1' onchange='setDest("+numLink+")' style='width: 150px' id='dest"+String(numLink)+"'>"+
								"</div>"+
								"<div class='input-group'>"+
									"<span class='input-group-addon'>value</span>"+
									"<input type='text' class='form-control' aria-describedby='basic-addon1' onchange='setLinkVal("+numLink+")' style='width: 185px'id='linkVal"+String(numLink)+"'>"+
								"</div>"+
								"<div class='input-group'>"+
									"<span class='input-group-addon' id='basic-addon1'>units</span>"+
									"<input type='text' class='form-control' aria-describedby='basic-addon1' onchange='updateDifference()' style='width: 190px'>"+
								"</div>"+
								"<div class='form-group' style='width: 245px'>"+
								//DELETE THE THING
								"<button class='btn btn-secondary' onclick='deleteLink()' style='background-color: #8f3236'><span class='glyphicon glyphicon-minus'></span></button>"+
									"<select class='form-control' id='sel1'>"+
									  "<option>Red</option>"+
									  "<option>Blue</option>"+
									  "<option>Yellow</option>"+
									  "<option>Orange</option>"+
									  "<option>Green</option>"+
									  "<option>Blue</option>"+
									  "<option>Purple</option>"+
									  "<option>Brown</option>"+
									"</select>"+
								  "</div>"+
							"</td>"+
						"</tr>"+
					"</tbody>"+
				"</table>"+
			"</div>"+
		"</div>"+
	"</div>";
	
    makeLinks.appendChild(newLink);
    numLink++;
}
//HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH
function deleteInput()
{
    //numNode--;
    //totalNumberOfInputsAndOutputs--;
    // for(var i = 0; i < sequence.length; i++){
        // if( sequence[i].id === ("output"+outputNumber)){
            // sequence.splice(i, 1);
            // break;
        // }
    // }
    newLink("td");
    //removeElementByID("output-spanner"+outputNumber);
    //loadOutputs();
   // moveDiffrenceTable();
}
// function deleteLink()
// {
	
	//document.getElementById(elementName).parentNode.removeChild(document.getElementById(elementName));
	
	
	
// }

// function removeElementsByClass(className){
    // var elements = document.getElementsByClassName(className);
    // while(elements.length > 0){
        // elements[0].parentNode.removeChild(elements[0]);
    // }
// }

// function deleteOutput(outputNumber){

    // columns--;
    // totalNumberOfInputsAndOutputs--;
    // for(var i = 0; i < sequence.length; i++){
        // if( sequence[i].id === ("output"+outputNumber)){
            // sequence.splice(i, 1);
            // break;
        // }
    // }

    // if(sankeyIsMade) {
        // var found = false;
        // var top = false;
        // var outputValue = 0;

        // for (var i = 0; i < nodeHandles.length; i++) {
            // if (nodeHandles[i].id === ("output" + outputNumber)) {
                // top = nodeHandles[i].top;
                // outputValue = nodeHandles[i + 1].lastValue;
                // nodeHandles.splice(i, 2);
                // found = true;
            // }
            // if (found) {
                // nodeHandles[i].x -= 230;
                // if (!top) {
                    // nodeHandles[i].y += calcDisplayValue(outputValue);
                // }
            // }
        // }

        // isNodeHandleDeleted = true;
    // }

    // removeElementByID("output"+outputNumber);
    // removeElementByID("output-spanner"+outputNumber);
    // loadOutputs();
    // moveDiffrenceTable();
// }

// function deleteInput(inputNumber){

    // columns--;
    // totalNumberOfInputsAndOutputs--;
    // for(var i = 0; i < sequence.length; i++){
        // if( sequence[i].id === ("input"+inputNumber)){
            // sequence.splice(i, 1);
            // break;
        // }
    // }

    // if(sankeyIsMade){
        // var found = false;
        // var top = false;
        // var outputValue = 0;

        // for(var i = 0; i < nodeHandles.length; i++){
            // if( nodeHandles[i].id === ("input"+inputNumber)){
                // top = nodeHandles[i].top;
                // outputValue = nodeHandles[i+1].lastValue;
                // nodeHandles.splice(i, 2);
                // found = true;
            // }
            // if(found){
                // nodeHandles[i].x -= 230;
                // if(!top){
                    // nodeHandles[i].y -= calcDisplayValue(outputValue);
                // }
            // }
        // }

        // isNodeHandleDeleted = true;
    // }

    // removeElementByID("input"+inputNumber);
    // removeElementByID("input-spanner"+inputNumber);
    // loadOutputs();
    // moveDiffrenceTable();
// }
//HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH
function update(){
    checkForValidSankeyMake();
    if(sankeyIsMade) {
        makeSankey('#sankey-display', false);
    }
}

function makeSankey()
{
    var data = [{
    type: "sankey",
        arrangement: "snap",
        node:{
            label: Label, //["A", "B", "C", "D", "E", "F"],
           // x: [0.2, 0.2, 0.5, 0.7, 0.3, 0.5],
           // y: [0.7, 0.5, 0.2, 0.4, 0.2, 0.3],
            pad:10}, // 10 Pixels
        link: {
            source: Source,
            target: dest,
            value: linkVal}
        }]

    var layout = {"title": mytitle}

    Plotly.newPlot('myDiv', data, layout, )
	
}
